#' Function for weighted zfi
#'
#' Computes weighted ZFI post hoc. Not efficient since it doubles up computation.
#' Meant to be temporary solution to weighted RMSE until it can be incorporated
#' into compute_zfi. 
#' 
#' !! if switching from monthly data beware !! 
#'
#' @param model Object output from fit_esn function.
#' @param zfi Object output from compute_zfi
#' @param y_spatial Matrix of observed response values on the spatial scale with
#'        rows corresponding to times and columns corresponding to spatial 
#'        locations (should be the same matrix used for Ztrain in compute_eofs).
#' @param phi Matrix object phi output from compute_eofs when applied to Ztrain.
#' @param weights Vector of length equal to number of columns of y_spatial. Weights
#'        should correspond to column order of y_spatial (that is they are spatial weights)
#' @param time_diff !! this is not generalizable to non-monthly data !! Integer for month ahead forecast FI you want. 
#'        defaults to 1 meaning one step ahead forecast FI
#'
#' @export compute_weighted_zfi
#'
#' @importFrom dplyr bind_cols filter full_join group_by left_join mutate rename
#'             select starts_with summarise
#' @importFrom lubridate as_date
#' @importFrom purrr map map_depth map_df
#' @importFrom tidyr pivot_longer pivot_wider

compute_weighted_zfi <- function(model,zfi,y_spatial,phi,weights,time_diff=1){
  
  # esn model predictions
  yhat <- predict_esn(model, phi = phi)
  forecast_times <- rownames(yhat$preds_ins)
  
  # observed data on same dates as forecasts
  y_train_mat_match <- y_spatial[rownames(y_spatial) %in% forecast_times,]
  
  # zeroed predictions
  yhat0 <- 
    zfi$preds_zeroed %>%
    dplyr::mutate(
      t_forecasted = lubridate::as_date(.data$t_forecasted),
      t_zeroed = lubridate::as_date(.data$t_zeroed),
      month_diff = lubridate::interval(.data$t_zeroed, .data$t_forecasted) %/% months(time_diff)) %>%
    dplyr::filter(.data$month_diff == time_diff)
  
  # rmse of obs vs esn
  rmse_obs_cltg <- sqrt(((y_train_mat_match-yhat$preds_ins)^2)%*%weights/sum(weights))
  
  # rmse of obs vs zereod, and zfi
  rmse_zero_cltg <- list()
  zfi_weighted <- list()
  
  vars <- unique(yhat0$vars_zeroed)
  
  for(i in 1:length(vars)){
    temp <- yhat0 %>% dplyr::filter(.data$vars_zeroed == vars[i])
    temp2 <- as.matrix(temp[,-c(1:3,ncol(temp))])
    rmse_zero_cltg[[i]] <- sqrt(((y_train_mat_match-temp2)^2)%*%weights/sum(weights))
    zfi_weighted[[i]] <- rmse_zero_cltg[[i]] - rmse_obs_cltg
  }
  
  #combine results into data.frame
  zfi_out <- data.frame(do.call("cbind",zfi_weighted))
  names(zfi_out) <- vars
  zfi_out <- zfi_out %>% 
    dplyr::mutate(t_forecasted = lubridate::as_date(row.names(zfi_out)),
           t_zeroed = .data$t_forecasted - months(time_diff)) %>%
    tidyr::pivot_longer(1:length(vars),names_to="vars_zeroed",values_to="zfi") %>%
    dplyr::mutate(vars_zeroed=factor(.data$vars_zeroed),t_zeroed=factor(.data$t_zeroed),t_forecasted=factor(.data$t_forecasted))
  return(zfi_out)
}


