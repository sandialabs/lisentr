#' Compute variable importance for individual EOFs (vertical FI). currently only implemented for ZFI
#'
#' @param model fitted ESN, output from either fit_esn or fit_Eesn
#' @param obs matrix of real (on original scale) observed data, should have same nrow as nrow of x matrix provided to fit_esn, ncol should 
#' be the number of spatial locations
#' @param eofs matrix of training EOFs for the response
#' 
#'
#' @export compute_vertical_fi
#'
#' @examples 
#' # to do

compute_vertical_fi <- function(model, obs, eofs) {

  predsList_train_changed <- list()
  predsList_test_changed <- list()
  
  predsList_train_real <- list()
  predsList_test_real <- list()
  
  #determine whether ensemble of ESNs
  if(length(names(model))==0){
    x <- model[[1]]$data_input$x
    t <- row.names(x)
    m <- model[[1]]$params_tuning$m
    
    for(j in 1:length(model)){
      predsList_train_changed[[j]] <- list()
      predsList_test_changed[[j]] <- list()
      
      predsList_train_real[[j]] <- list()
      predsList_test_real[[j]] <- list()
      
      for(i in 1:ncol(x)){
        x_new <- x
        x_new[,i] <- 0#x_new[sample(1:nrow(x),nrow(x),replace=FALSE),i]
        #x_test_new <- x_test
        #x_test_new[,i] <- 0#x_new[sample(1:nrow(x),nrow(x),replace=FALSE),i]
        temp_train = predict_esn(model = model[[j]],x_ood=x_new,t_new=t)
        #temp_test = predict_esn(model = model[[j]],x_new=x_test_new,t_new=t_test)
        predsList_train_changed[[j]][[i]] <- temp_train$preds_ood%*%t(eofs)
        #predsList_test_changed[[j]][[i]] <- temp_test$preds_new%*%t(eofs_temp_strat$phi)
        
        temp_train_real = predict_esn(model = model[[j]],x_ood=x,t_new=t)
        #temp_test_real = predict_esn(model = model[[j]],x_new=x_test,t_new=t_test)
        predsList_train_real[[j]][[i]] <- temp_train_real$preds_ood%*%t(eofs)
        #predsList_test_real[[j]][[i]] <- temp_test_real$preds_new%*%t(eofs_temp_strat$phi)
      }
    }
    
    fi_mat <- matrix(NA,nrow=ncol(x),ncol=length(model))

    for(i in 1:length(model)){
      fi_train <- sapply(1:ncol(x),function(x){
        real <- sqrt(rowMeans((predsList_train_real[[i]][[x]]-obs[-c(1:(m+1)),])^2)) 
        changed <- sqrt(rowMeans((predsList_train_changed[[i]][[x]]-obs[-c(1:(m+1)),])^2)) 
        return(changed-real)
      })
      fi_mat[,i] <- colMeans(fi_train)
    }
    return(fi_mat)
  }
  
  else{
    
    x <- model$data_input$x
    t <- row.names(x)
    m <- model$params_tuning$m
    
    for(i in 1:ncol(x)){
      x_new <- x
      x_new[,i] <- 0#x_new[sample(1:nrow(x),nrow(x),replace=FALSE),i]
      #x_test_new <- x_test
      #x_test_new[,i] <- 0#x_new[sample(1:nrow(x),nrow(x),replace=FALSE),i]
      temp_train = predict_esn(model = model,x_ood=x_new,t_new=t)
      #temp_test = predict_esn(model = model,x_new=x_test_new,t_new=t_test)
      predsList_train_changed[[i]] <- temp_train$preds_ood%*%t(eofs)
      #predsList_test_changed[[i]] <- temp_test$preds_new%*%t(eofs_temp_strat$phi)
      
      temp_train_real = predict_esn(model = model,x_ood=x,t_new=t)
      #temp_test_real = predict_esn(model = model,x_new=x_test,t_new=t_test)
      predsList_train_real[[i]] <- temp_train_real$preds_ood%*%t(eofs)
      #predsList_test_real[[i]] <- temp_test_real$preds_new%*%t(eofs_temp_strat$phi)
    }
    
    fi_out <- sapply(1:ncol(x),function(x){
      real <- sqrt(rowMeans((predsList_train_real[[x]]-obs[-c(1:(m+1)),])^2))
      changed <- sqrt(rowMeans((predsList_train_changed[[x]]-obs[-c(1:(m+1)),])^2))
      return(changed-real)
    })
    return(fi_out)
  }

}
