#' Simulated dataset
#'
#' A simulated dataset generate for `listenr` examples. For the code used to 
#' prepare this dataset, see
#' https://github.com/sandialabs/listenr/inst/package-data-prep/prep-sim-data.md.
#'
#' @format A data.frame.

"sim"