#' Function for computing ZFI with ESN
#'
#' Computes ZFI using the training data specified in fit_esn (option to compute
#' ZFI with retraining)
#'
#' @param model Object output from fit_esn function
#' @param var_groups List of vectors where each vectors contains columns numbers
#'        indicating which x variables should be grouped when doing the
#'        zeroing process (set to NULL by default which zeros all x variables)
#' @param blockSize Total number of time points to zero out, defaults to 1 
#'        (standard ZFI)
#' @param nretrains Number of times to retrain ESN when computing ZFI. Default 
#'        is 0 (e.g., no retraining.)
#' @param y_spatial Matrix of observed response values on the spatial scale with
#'        rows corresponding to times and columns corresponding to spatial 
#'        locations (should be the same matrix used for Ztrain in compute_eofs).
#' @param phi Matrix object phi output from compute_eofs when applied to Ztrain.
#' @param scale_y Indicates whether y and corresponding predictions should be
#'        scaled before computing RMSEs. Scaling y values and predictions is 
#'        intended to put multiple response variables on the same scale 
#'        for comparison in the computation of ZFI. (Default is FALSE.)
#' @param return_zeroed_preds Indicates whether the zeroed predictions are
#'        returned in addition to ZFI values.
#' @param seed Random seed
#'
#' @export compute_zfi
#'
#' @importFrom dplyr filter full_join group_by left_join mutate rename
#'             select starts_with summarise
#' @importFrom lubridate as_date
#' @importFrom purrr map map_depth map_df
#' @importFrom tibble remove_rownames
#' @importFrom tidyr pivot_longer pivot_wider
#' 
#' @examples 
#' # Create data
#' x = matrix(rnorm(40,0,1), ncol = 4)
#' y = matrix(rnorm(20,0,1), ncol = 2)
#' 
#' # Assign column names
#' colnames(x) = c("x11", "x12", "x21", "x22")
#' colnames(y) = c("y1", "y2")
#' 
#' # Times
#' t = paste0("t", 1:10)
#' 
#' # Fit an ESN model
#' esn <- 
#'   fit_esn(
#'     x = x, 
#'     y = y, 
#'     t = t, 
#'     tau = 2, 
#'     m = 1, 
#'     tau_emb = 1, 
#'     nh = 10, 
#'     seed = 1020349858
#'   )
#' 
#' # Compute ZFI
#' zfi <- 
#'   compute_zfi(
#'     model = esn, 
#'     var_groups = list(1:2, 3:4), 
#'     seed = 10203498,
#'     blockSize = 1
#'    )

# model = esn
# var_groups = list(1:2, 3:4)
# y_spatial = NULL
# phi = NULL
# scale_y = FALSE
# blockSize = 1
# seed = 10203040
# return_zeroed_preds = TRUE
# nretrains = 2

compute_zfi <- function(model, var_groups = NULL, blockSize = 1, nretrains = 0, 
                        y_spatial = NULL, phi = NULL, scale_y = FALSE,
                        return_zeroed_preds = FALSE, seed) {

  #### PREDICTIONS ON OBSERVED DATA ####
  
  # Extract observed in-sample y values or if specified, use y_spatial (with 
  # times removed according)
  if (is.null(y_spatial)) {
    y_obs = model$data_train$y_train
  } else {
    y_obs <-
      create_data_obj_y(
        y = y_spatial,
        t = model$data_input$t,
        tau = model$params_tuning$tau,
        m = model$params_tuning$m,
        tau_emb = model$params_tuning$tau_emb,
        internal_scaling = "none"
      )$y_train
  }
  
  # Compute predictions on in-sample data (will compute on spatial 
  # scale if phi is not NULL)
  y_pred = predict_esn(model = model, phi = phi)$preds_ins
  
  # If specified, scale obs and pred y
  if (scale_y) {
    y_obs = scale(y_obs)
    y_pred = scale(y_pred)
  }
  
  # Compute RMSEs on predictions from observed data
  rmses_obs = sqrt(rowMeans((y_obs - y_pred)^2))

  #### PREDICTIONS AND RMSES ON ZEROED DATA ####
  
  # If var_groups is NULL, set var_groups to contain all x vars
  if (is.null(var_groups)) {
    var_groups = list(1:ncol(model$data_input$x))
  }
  
  # Compute RMSEs with zeroed data
  if (nretrains == 0) {
  
    # Returns an array of dimensions (no. times, no. var_groups)
    set.seed(seed)
    rmses_zeroed <-
      purrr::map(
        .x = blockSize:(length(model$data_train$x_train_times)),
        .f = function(t) {
          purrr::map(
            .x = var_groups,
            .f = compute_zeroed_rmses,
            zeroed_index = t,
            y_obs = y_obs,
            model = model,
            blockSize = blockSize,
            y_spatial = y_spatial, 
            phi = phi, 
            scale_y = scale_y, 
            retrain = FALSE,
            seed = seed, 
            return_zeroed_preds = return_zeroed_preds
          )
        }
      )
    
  } else {
    
    # Returns an array of dimensions (no. retrains, no. times, no. var_groups)
    set.seed(seed)
    rmses_zeroed <-
      purrr::map2(
        .x = 1:nretrains,
        .y = seed * (1:nretrains),
        .f = function(rep, seed) {
          purrr::map(
            .x = blockSize:(length(model$data_train$x_train_times)),
            .f = function(t) {
              purrr::map(
                .x = var_groups,
                .f = compute_zeroed_rmses,
                zeroed_index = t,
                y_obs = y_obs,
                model = model,
                blockSize = blockSize,
                y_spatial = y_spatial, 
                phi = phi, 
                scale_y = scale_y, 
                retrain = TRUE,
                return_zeroed_preds = return_zeroed_preds,
                seed = seed
              )
            }
          )
        }
      )
    
  }
  
  #### ZFI COMPUTATIONS ####
  
  # Extract times associated with x and y
  x_train_times = model$data_train$x_train_times
  y_train_times = model$data_train$y_train_times
  
  # Prepare var_group labels for data frames
  var_groups_label <-
    purrr::map_chr(
      .x = var_groups,
      .f = function(x)
        paste(x, collapse = ",")
    )
  
  # Compute ZFI values (within a var group) and convert to a data frame
  if (nretrains == 0) {
    
    # Create data frame containing labels to attached with ZFIs
    zfi_labels <-
      data.frame(
        expand.grid(
          t_forecasted = y_train_times,
          vars_zeroed = var_groups_label,
          t_zeroed = x_train_times[blockSize:length(x_train_times)]
        )
      )
    
    # Compute ZFI values, convert to a data frame, and attach labels
    zfi <-
      purrr::map_depth(
        .x = rmses_zeroed,
        .depth = 2,
        .f = function(rmses_zeroed)
          data.frame(zfi = -rmses_obs - (-rmses_zeroed$rmses))
      ) %>%
      purrr::flatten() %>%
      purrr::map_df(.f = data.frame) %>%
      dplyr::bind_cols(zfi_labels) %>%
      dplyr::select(
        .data$vars_zeroed,
        .data$t_zeroed,
        .data$t_forecasted,
        .data$zfi
      )
    
  } else {
    
    # Create data frame containing labels to attached with ZFIs
    zfi_labels <-
      data.frame(
        expand.grid(
          t_forecasted = y_train_times,
          vars_zeroed = var_groups_label,
          t_zeroed = x_train_times[blockSize:length(x_train_times)],
          retrain = 1:nretrains
        )
      )
    
    # Compute ZFI values, convert to a data frame, and attach labels
    zfi_by_retrain <-
      purrr::map_depth(
        .x = rmses_zeroed,
        .depth = 3,
        .f = function(rmses_zeroed)
          data.frame(zfi = -rmses_obs - (-rmses_zeroed$rmses))
      ) %>%
      purrr::flatten() %>%
      purrr::flatten() %>%
      purrr::map_df(.f = data.frame) %>%
      dplyr::bind_cols(zfi_labels) %>%
      dplyr::select(
        .data$retrain,
        .data$vars_zeroed,
        .data$t_zeroed,
        .data$t_forecasted,
        .data$zfi
      )
    
    # Compute ZFI (averaged over reps)
    zfi <-
      zfi_by_retrain %>%
      dplyr::group_by(.data$vars_zeroed, .data$t_zeroed, .data$t_forecasted) %>%
      dplyr::summarise(
        zfi_mean = mean(.data$zfi),
        zfi_sd = sd(.data$zfi),
        zfi_min = min(.data$zfi),
        zfi_max = max(.data$zfi),
        .groups = "drop"
      )
    
  }
  

  #### ZEROED PREDICTIONS CLEAN UP ####
  
  # If requested, extract zeroed predictions and put in a dataframe
  if (return_zeroed_preds) {
    
    # Without retraining
    if (nretrains == 0) {
      preds_zeroed <-
        purrr::map_depth(
          .x = rmses_zeroed,
          .depth = 2,
          .f = function(rmses_zeroed)
            data.frame(rmses_zeroed$preds)
        ) %>%
        purrr::flatten() %>%
        purrr::map_df(.f = data.frame) %>% 
        dplyr::bind_cols(zfi_labels) %>%
        tibble::remove_rownames() %>%
        dplyr::select(
          .data$vars_zeroed,
          .data$t_zeroed,
          .data$t_forecasted,
          dplyr::everything()
        )
      
    # With retraining 
    } else {
      preds_zeroed <-
        purrr::map_depth(
          .x = rmses_zeroed,
          .depth = 3,
          .f = function(rmses_zeroed)
            data.frame(rmses_zeroed$preds)
        ) %>%
        purrr::flatten() %>%
        purrr::flatten() %>%
        purrr::map_df(.f = data.frame) %>% 
        dplyr::bind_cols(zfi_labels) %>%
        tibble::remove_rownames() %>%
        dplyr::select(
          .data$retrain,
          .data$vars_zeroed,
          .data$t_zeroed,
          .data$t_forecasted,
          dplyr::everything()
        )
    }
  
  }
    
  #### RESULTS ####
  
  # Return ZFI results
  res = list(zfi = zfi)
  if (nretrains != 0) {
    res$nretrains = nretrains
    res$zfi_by_retrain = zfi_by_retrain
  }
  if (return_zeroed_preds) res$preds_zeroed = preds_zeroed 
  return(res)

}
