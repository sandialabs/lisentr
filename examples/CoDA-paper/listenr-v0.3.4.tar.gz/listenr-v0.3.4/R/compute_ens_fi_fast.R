#' Parallelized Function for computing FI of Ensembled ESN
#'
#' Computes PFI/ZFI using the training data specified in fit_Eesn (option to 
#' compute feature importance with retraining.)
#'
#' @param modelList Object output from fit_Eesn function (list of ESN fits)
#' @param type Character equal to "pfi" or "zfi", depending which type of fi 
#'        you want to compute
#' @param var_groups List of vectors where each vectors contains columns numbers
#'        indicating which x variables should be grouped when doing the
#'        zeroing process (set to NULL by default which zeros all x variables)
#' @param blockSize Total number of time points to zero out. Default is 1
#'        (i.e., standard PFI/ZFI).
#' @param nreps Number of reps to use when computing PFI.
#' @param y_spatial Matrix of observed response values on the spatial scale with
#'        rows corresponding to times (same times and ordering as in
#'        model$data_train$y_train_times) and columns corresponding to spatial 
#'        locations (same locations and ordering as in the Ztrain matrix input 
#'        to compute_eofs). Note that the number of times in y_spatial will be
#'        less than the number of rows input as the Ztrain matrix since the 
#'        ESN will have reduce the number of times based on tau from fit_esn.
#' @param phi Matrix object phi output from compute_eofs when applied to Ztrain.
#' @param weights Vector of weights with length corresponding to the number of 
#'        columns in y (or y_spatial, if y_spatial is specified) Note: currently
#'        assumes that the weights are equivalent across time -- only varies by
#'        location.
#' @param scale_y Indicates whether y and corresponding predictions should be
#'        scaled before computing RMSEs. Scaling y values and predictions is 
#'        intended to put multiple response variables on the same scale 
#'        for comparison in the computation of PFI. Default is FALSE.
#' @param return_adj_preds Indicates whether the permuted/zeroed predictions are
#'        returned in addition to PFI/ZFI values. Default is FALSE.
#' @param cores number of cores to use for parallelizing
#' @param seed Random seed
#'
#' @export compute_ens_fi_fast
#'
#' @importFrom future multisession plan sequential
#' @importFrom furrr furrr_options future_map
#' 
#' @examples 
#' # Create data
#' x = matrix(rnorm(40,0,1), ncol = 4)
#' y = matrix(rnorm(20,0,1), ncol = 2)
#' 
#' # Assign column names
#' colnames(x) = c("x11", "x12", "x21", "x22")
#' colnames(y) = c("y1", "y2")
#' 
#' # Times
#' t = paste0("t", 1:10)
#' 
#' # Fit an ESN model
#' esnList <- 
#'   fit_Eesn(
#'     x = x, 
#'     y = y, 
#'     t = t, 
#'     tau = 2, 
#'     m = 1, 
#'     tau_emb = 1, 
#'     nh = 10, 
#'     seed = 102034985,
#'     n_ensembles=10,
#'     cores=1
#'   )
#' 
#' # Compute ZFI
#' zfi <- 
#'   compute_ens_fi_fast(
#'     modelList = esnList, 
#'     type = "zfi", 
#'     var_groups = list(1:2, 3:4),
#'     blockSize = 1,
#'     cores = 2,
#'     seed = 102034985
#'    )

# modelList = esnList
# type = "zfi"
# var_groups = list(1:2, 3:4)
# blockSize = 1
# nreps = 2
# y_spatial = NULL
# phi = NULL
# scale_y = FALSE
# cores = 2
# seed = 102034985

# modelList = eesn
# type = "pfi"
# var_groups = list(1:n_eofs, (n_eofs + 1):(2 * n_eofs))
# blockSize = nblocks
# nreps = nreps
# y_spatial = train_mat_temp_strat
# phi = phi_train
# seed = 202304
# cores = 6

compute_ens_fi_fast <- 
  function(modelList, type, var_groups = NULL, blockSize = 1, nreps = NULL, 
           y_spatial = NULL, phi = NULL, weights = NULL, scale_y = FALSE, 
           return_adj_preds = FALSE, cores = 1, seed) {
  
  # Defining 'i' to get R check note of "no visible binding for
  # global variable ‘i’" to go away
  i <- NULL
  cl <- parallel::makeCluster(cores)
  doParallel::registerDoParallel(cl)
  fiList <- foreach::foreach(i=1:length(modelList),.packages="listenr") %dopar% {
    fi <-
      compute_fi_fast(
        model = modelList[[i]],
        type = type,
        nreps = nreps,
        var_groups = var_groups,
        y_spatial = y_spatial,
        phi = phi,
        weights = weights,
        scale_y = scale_y,
        blockSize = blockSize,
        return_adj_preds = return_adj_preds,
        seed = i*seed+34
      )
    fi
  }
  parallel::stopCluster(cl)
  
  # future::plan(future::multisession, workers = cores)
  # fiList <- furrr::future_map(
  #   .x = modelList,
  #   .f = compute_fi_fast,
  #   type = type,
  #   nreps = nreps,
  #   var_groups = var_groups,
  #   blockSize = blockSize,
  #   y_spatial = y_spatial,
  #   phi = phi,
  #   scale_y = scale_y,
  #   .options = furrr::furrr_options(seed = seed),
  #   .progress = TRUE
  # )
  # future::plan(future::sequential)
      
  return(fiList)

  }
