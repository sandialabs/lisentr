#' Function for computing PFI with ESN
#'
#' Computes PFI using the training data specified in fit_esn (option to compute
#' PFI with retraining)
#'
#' @param model Object output from fit_esn function.
#' @param nreps Number of reps to use when computing PFI.
#' @param retrain Indicates whether the ESN should be retrained with permuted 
#'        data when computing PFI. Default is FALSE.
#' @param var_groups List of vectors where each vectors contains columns 
#'        numbers indicating which x variables should be grouped when doing the
#'        permutation (set to NULL by default which permutes all x variables)
#' @param blockSize Total number of time points to permute. Default is 1
#'        (i.e., standard PFI).
#' @param y_spatial Matrix of observed response values on the spatial scale with
#'        rows corresponding to times and columns corresponding to spatial 
#'        locations (should be the same matrix used for Ztrain in compute_eofs).
#' @param phi Matrix object phi output from compute_eofs when applied to Ztrain.
#' @param scale_y Indicates whether y and corresponding predictions should be
#'        scaled before computing RMSEs. Scaling y values and predictions is 
#'        intended to put multiple response variables on the same scale 
#'        for comparison in the computation of PFI. Default is FALSE.
#' @param return_perm_preds Indicates whether the permuted predictions are
#'        returned in addition to PFI values. Default is FALSE.
#' @param seed Random seed
#'
#' @export compute_pfi
#'
#' @importFrom dplyr bind_cols filter full_join group_by left_join mutate rename
#'             select starts_with summarise
#' @importFrom lubridate as_date
#' @importFrom purrr map map_depth map_df
#' @importFrom tidyr pivot_longer pivot_wider
#' 
#' @examples 
#' # Create data
#' x = matrix(rnorm(40,0,1), ncol = 4)
#' y = matrix(rnorm(20,0,1), ncol = 2)
#' 
#' # Assign column names
#' colnames(x) = c("x11", "x12", "x21", "x22")
#' colnames(y) = c("y1", "y2")
#' 
#' # Times
#' t = paste0("t", 1:10)
#' 
#' # Fit an ESN model
#' esn <- 
#'   fit_esn(
#'     x = x, 
#'     y = y, 
#'     t = t, 
#'     tau = 2, 
#'     m = 1, 
#'     tau_emb = 1,
#'     nh = 10, 
#'     seed = 1020349858
#'   )
#' 
#' # Compute PFI
#' pfi <- 
#'   compute_pfi(
#'     model = esn, 
#'     nreps = 5, 
#'     var_groups = list(1:2, 3:4), 
#'     seed = 1020349858
#'   )

# model = esn
# nreps = 2
# var_groups = list(1:2, 3:4)
# y_spatial = NULL
# phi = NULL
# scale_y = FALSE
# blockSize = 1
# seed = 10203040
# return_perm_preds = TRUE
# retrain = FALSE

compute_pfi <- function(model, nreps, var_groups = NULL, blockSize = 1,
                        retrain = FALSE, y_spatial = NULL, phi = NULL, 
                        scale_y = FALSE, return_perm_preds = FALSE, seed) {

  #### PREDICTIONS ON OBSERVED DATA ####
  
  # Extract observed in-sample y values or if specified, use y_spatial (with 
  # times removed according)
  if (is.null(y_spatial)) {
    y_obs = model$data_train$y_train
  } else {
    y_obs <-
      create_data_obj_y(
        y = y_spatial,
        t = model$data_input$t,
        tau = model$params_tuning$tau,
        m = model$params_tuning$m,
        tau_emb = model$params_tuning$tau_emb,
        internal_scaling = "none"
      )$y_train
  }
  
  # Compute predictions on in-sample data (will compute on spatial scale if
  # phi is not NULL)
  y_pred = predict_esn(model = model, phi = phi)$preds_ins
  
  # If specified, scale obs and pred y
  if (scale_y) {
    y_obs = scale(y_obs)
    y_pred = scale(y_pred)
  }
  
  # Compute RMSEs on predictions from observed data
  rmses_obs = sqrt(rowMeans((y_obs - y_pred)^2))

  #### PREDICTIONS ON PERMUTED DATA ####
  
  # If var_groups is NULL, set var_groups to contain all x vars
  if (is.null(var_groups)) {
    var_groups = list(1:ncol(model$data_input$x))
  }
  
  # Compute RMSEs with permuted data
  # Returns an array of dimensions (no. reps, no. times, no. var_groups)
  set.seed(seed)
  rmses_perm <-
    purrr::map(
      .x = 1:nreps,
      .f = function(rep) {
        purrr::map(
          .x = blockSize:(length(model$data_train$x_train_times)),
          .f = function(t) {
            purrr::map(
              .x = var_groups,
              .f = compute_perm_rmses,
              perm_index = t,
              y_obs = y_obs,
              model = model,
              blockSize = blockSize,
              y_spatial = y_spatial, 
              phi = phi, 
              scale_y = scale_y, 
              retrain = retrain,
              seed = seed * rep,
              return_perm_preds = return_perm_preds
            )
          }
        )
      }
    )
  
  #### PFI COMPUTATIONS ####
  
  # Extract times associated with x and y
  x_train_times = model$data_train$x_train_times
  y_train_times = model$data_train$y_train_times
  
  # Prepare var_group labels for data frames
  var_groups_label <-
    purrr::map_chr(
      .x = var_groups,
      .f = function(x)
        paste(x, collapse = ",")
    )
  
  # Create data frame containing labels to attached with PFIs
  pfi_labels <-
    data.frame(
      expand.grid(
        t_forecasted = y_train_times,
        vars_perm = var_groups_label,
        t_perm = x_train_times[blockSize:length(x_train_times)],
        rep = 1:nreps
      )
    )
  
  # Compute PFI values, convert to a data frame, and attach labels
  pfi_by_rep <-
    purrr::map_depth(
      .x = rmses_perm,
      .depth = 3,
      .f = function(rmses_perm)
        data.frame(pfi = -rmses_obs - (-rmses_perm$rmses))
    ) %>%
    purrr::flatten() %>%
    purrr::flatten() %>%
    purrr::map_df(.f = data.frame) %>%
    dplyr::bind_cols(pfi_labels) %>%
    dplyr::select(
      .data$rep,
      .data$vars_perm,
      .data$t_perm,
      .data$t_forecasted,
      .data$pfi
    )

    # Compute PFI (averaged over reps)
    pfi <-
      pfi_by_rep %>%
      dplyr::group_by(.data$vars_perm, .data$t_perm, .data$t_forecasted) %>%
      dplyr::summarise(
        pfi_mean = mean(.data$pfi),
        pfi_sd = sd(.data$pfi),
        pfi_min = min(.data$pfi),
        pfi_max = max(.data$pfi),
        .groups = "drop"
      )

  #### PERMUTED PREDICTIONS CLEAN UP ####
  
  # If requested, extract permuted predictions and put in a dataframe
  if (return_perm_preds) {
    preds_perm <-
      purrr::map_depth(
        .x = rmses_perm,
        .depth = 3,
        .f = function(rmses_perm)
          data.frame(rmses_perm$preds)
      ) %>%
      purrr::flatten() %>%
      purrr::flatten() %>%
      purrr::map_df(.f = data.frame) %>% 
      dplyr::bind_cols(pfi_labels) %>%
      tibble::remove_rownames() %>%
      dplyr::select(
        .data$rep,
        .data$vars_perm,
        .data$t_perm,
        .data$t_forecasted,
        dplyr::everything()
      )
  }

  #### RESULTS ####
  
  # Return PFI results
  res = list(pfi = pfi, pfi_by_rep = pfi_by_rep, nreps = nreps, retrain = retrain)
  if (return_perm_preds) res$preds_perm = preds_perm
  return(res)

}
