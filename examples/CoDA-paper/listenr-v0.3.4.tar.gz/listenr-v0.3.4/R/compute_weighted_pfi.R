#' Function for weighted pfi
#'
#' Computes weighted PFI post hoc. Not efficient since it doubles up computation.
#' Meant to be temporary solution to weighted RMSE until it can be incorporated
#' into compute_pfi. 
#' 
#' !! if switching from monthly data beware !! 
#'
#' @param model Object output from fit_esn function.
#' @param pfi Object output from compute_pfi
#' @param y_spatial Matrix of observed response values on the spatial scale with
#'        rows corresponding to times and columns corresponding to spatial 
#'        locations (should be the same matrix used for Ztrain in compute_eofs).
#' @param phi Matrix object phi output from compute_eofs when applied to Ztrain.
#' @param weights Vector of length equal to number of columns of y_spatial. Weights
#'        should correspond to column order of y_spatial (that is they are spatial weights)
#' @param time_diff !! this is not generalizable to non-monthly data !! Integer for month ahead forecast FI you want. 
#'        defaults to 1 meaning one step ahead forecast FI
#'
#' @export compute_weighted_pfi
#'
#' @importFrom dplyr bind_cols filter full_join group_by left_join mutate rename
#'             select starts_with summarise
#' @importFrom lubridate as_date interval
#' @importFrom purrr map map_depth map_df
#' @importFrom tidyr pivot_longer pivot_wider

compute_weighted_pfi <- function(model,pfi,y_spatial,phi,weights,time_diff=1){
  
  # esn model predictions
  yhat <- predict_esn(model,phi=phi)
  forecast_times <- rownames(yhat$preds_ins)
  
  # observed data on same dates as forecasts
  y_train_mat_match <- y_spatial[rownames(y_spatial) %in% forecast_times,]
  
  # perm predictions
  yhat0 <- pfi$preds_perm %>%
    dplyr::mutate(t_forecasted = lubridate::as_date(.data$t_forecasted),
           t_perm = lubridate::as_date(.data$t_perm),
           month_diff = lubridate::interval(.data$t_perm, .data$t_forecasted) %/% months(time_diff)) %>%
    dplyr::filter(.data$month_diff == time_diff)
  
  # rmse of obs vs esn
  rmse_obs_cltg <- sqrt(((y_train_mat_match-yhat$preds_ins)^2)%*%weights/sum(weights))
  
  # rmse of obs vs zereod, and pfi
  rmse_zero_cltg <- list()
  pfi_weighted <- list()
  
  vars <- unique(yhat0$vars_perm)
  pfi_reps <- unique(pfi$preds_perm$rep)
  
  for(i in 1:length(vars)){
    rmse_zero_cltg_list <- list()
    for(j in 1:length(pfi_reps)){
      temp <- yhat0 %>% dplyr::filter(.data$vars_perm == vars[i],.data$rep == pfi_reps[j])
      temp2 <- as.matrix(temp[,-c(1:4,ncol(temp))])
      rmse_zero_cltg_list[[i]] <- sqrt(((y_train_mat_match-temp2)^2)%*%weights/sum(weights))
    }
    
    rmse_zero_cltg <- rowMeans(do.call("cbind",rmse_zero_cltg_list))
    pfi_weighted[[i]] <- rmse_zero_cltg - rmse_obs_cltg
  }
  
  #combine results into data.frame
  pfi_out <- data.frame(do.call("cbind",pfi_weighted))
  names(pfi_out) <- vars
  pfi_out <- pfi_out %>% 
    mutate(t_forecasted = lubridate::as_date(row.names(pfi_out)),
           t_perm = .data$t_forecasted - months(time_diff)) %>%
    tidyr::pivot_longer(1:length(vars),names_to="vars_perm",values_to="pfi") %>%
    dplyr::mutate(vars_perm = factor(.data$vars_perm), t_perm = factor(.data$t_perm), t_forecasted = factor(.data$t_forecasted))
  return(pfi_out)
}


