#' Function for getting "zeroed" RMSEs
#'
#' Sets the variables values for the specified time to 0 and obtains ESN
#' predictions with the "zeroed" times and computes RMSEs
#'
#' @param var_group Vectors of integers indicating the numbers of columns
#'        that should be included in the zeroing process
#' @param zeroed_index Integer specifying which time (zeroed_index + tau) 
#'        should be set to 0
#' @param y_obs Matrix of y values as computed internally in compute_zfi
#' @param model Model output from fit_esn function
#' @param blockSize number of time points to zero out for ZFI
#' @param y_spatial Matrix of observed response values on the spatial scale with
#'        rows corresponding to times and columns corresponding to spatial 
#'        locations (should be the same matrix used for Ztrain in compute_eofs).
#' @param phi Matrix object phi output from compute_eofs when applied to Ztrain.
#' @param scale_y Indicates whether y and corresponding predictions should be
#'        scaled before computing RMSEs. Scaling y values and predictions is 
#'        intended to put multiple response variables on the same scale 
#'        for comparison in the computation of PFI. (Default is FALSE.)
#' @param retrain Indicator for whether ZFI is being computed using retraining.
#' @param return_zeroed_preds Indicates whether the zeroed predictions are
#'        returned in addition to ZFI values.
#' @param seed Random seed
#' 
#' @export compute_zeroed_rmses
#'
#' @importFrom dplyr .data everything select
#' @importFrom stringr str_remove

# var_group = var_groups[[1]]
# zeroed_index = 1

compute_zeroed_rmses <- function(var_group, zeroed_index, y_obs, model, 
                                 blockSize, y_spatial, phi, scale_y, retrain,
                                 return_zeroed_preds, seed) {
  
  # Extract observed x training values
  x = model$data_input$x
  
  # Determine number of x variables to be set to zero
  n_xvars = length(var_group)
  
  # Set specified time(s) and variables to 0
  x_zeroed = x
  zeroed_index_init = zeroed_index - blockSize + 1
  x_zeroed[zeroed_index_init:zeroed_index,var_group] = rep(0, n_xvars)
  
  # If computing ZFI with retraining, train ESN with zeroed time(s)
  if (retrain) {
    model_zeroed <-
      fit_esn(
        x = x_zeroed,
        y = model$data_input$y,
        t = model$data_input$t,
        tau = model$params_tuning$tau,
        m = model$params_tuning$m,
        tau_emb = model$params_tuning$tau_emb,
        nh = model$params_tuning$nh,
        h_start = model$h$h_start,
        U_width = model$params_tuning$U_width,
        W_width = model$params_tuning$W_width,
        U_pi = model$params_tuning$U_pi,
        W_pi = model$params_tuning$W_pi,
        nu = model$params_tuning$nu,
        reg_par = model$params_tuning$reg_par,
        add_quad = model$add_quad,
        internal_scaling = model$internal_scaling, 
        seed = seed
      )
    
  # If computing ZFI without retraining, fill in existing model object with
  # zeroed times(s)
  } else {
    
    # Prepare data for ESN with zeroed time
    data_obj_zeroed <-
      create_data_obj_ood(
        model = model, 
        x_ood = x_zeroed, 
        t_ood = model$data_input$t
      )
    
    # Compute h matrix with zeroed values
    h_obj_zeroed <-
      create_h(
        U_and_W = model$param_est,
        data_obj = data_obj_zeroed,
        add_quad = model$add_quad,
        nh = model$params_tuning$nh,
        h_start = rep(0, model$params_tuning$nh)
      )
    
    # Fill in model with zeroed values
    model_zeroed = model
    model_zeroed$data_train$x_train = data_obj_zeroed$x_ood
    model_zeroed$data_train$x_train_scaled = data_obj_zeroed$x_ood_scaled
    model_zeroed$data_train$x_oos = data_obj_zeroed$x_ood_oos
    model_zeroed$data_train$emb_vecs = data_obj_zeroed$emb_vecs
    model_zeroed$data_train$design_matrix = data_obj_zeroed$design_matrix
    model_zeroed$h = h_obj_zeroed
    
  }
  
  # Compute predictions with permuted model version (will compute on spatial 
  # scale if phi is not NULL)
  preds_zeroed = predict_esn(model_zeroed, phi = phi)$preds_ins
  
  # Scale predictions if requested
  if (scale_y) preds_zeroed = scale(preds_zeroed)
  
  # Compute RMSEs with zeroed data
  rmses_zeroed = sqrt(rowMeans((y_obs - preds_zeroed)^2))
  
  # Return RMSEs and predictions
  res = list(rmses = rmses_zeroed)
  if (return_zeroed_preds) res$preds = preds_zeroed
  return(res)
  
}
