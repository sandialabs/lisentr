#' Function for getting "adjusted" RMSEs
#'
#' Sets the variables values for the specified time to 0 and obtains ESN
#' predictions with the "adjusted" times and computes RMSEs
#'
#' @param var_group Vectors of integers indicating the numbers of columns
#'        that should be included in the permuting/zeroing process
#' @param index_adj Integer specifying which time should be permuted or
#'        set to 0
#' @param type Feature importance type to be computed ('pfi' or 'zfi')
#' @param y_obs Matrix of y values as computed internally in compute_zfi
#' @param model Model output from fit_esn function
#' @param blockSize number of time points to permute or zero out
#' @param y_spatial Matrix of observed response values on the spatial scale with
#'        rows corresponding to times and columns corresponding to spatial 
#'        locations (should be the same matrix used for Ztrain in compute_eofs).
#' @param weights Vector of weights with length corresponding to the number of 
#'        columns in y (or y_spatial, if y_spatial is specified) Note: currently
#'        assumes that the weights are equivalent across time -- only varies by
#'        location.
#' @param phi Matrix object phi output from compute_eofs when applied to Ztrain.
#' @param scale_y Indicates whether y and corresponding predictions should be
#'        scaled before computing RMSEs. Scaling y values and predictions is 
#'        intended to put multiple response variables on the same scale 
#'        for comparison in the computation of PFI. (Default is FALSE.)
#' @param return_adj_preds Indicates whether the permuted/zeroed predictions are
#'        returned in addition to PFI/ZFI values. Default is FALSE.
#' @param rep Used only for keeping track of reps associated with 
#'        `compute_fi_fast` (Default is NULL.)
#'        
#' @importFrom magrittr %>%
#' @export compute_adj_rmses_fast
#'
#' @importFrom dplyr .data everything select
#' @importFrom stringr str_remove

# var_group = var_groups[[1]]
# index_adj = x_index_adj_start
# rep = 1

compute_adj_rmses_fast <- function(var_group, index_adj, type, y_obs, model, 
                                   blockSize, y_spatial, phi, weights, scale_y, 
                                   return_adj_preds, rep = NULL) {
  
  # Extract observed x training values
  x = model$data_input$x
  
  # Determine number of x variables to be permuted or set to zero
  n_xvars = length(var_group)
  
  # Permute or set specified time(s) and variables to 0
  x_adj = x
  index_adj_init = index_adj - blockSize + 1
  indices_adj = index_adj_init:index_adj
  if (type == "zfi") {
    x_adj[indices_adj,var_group] = rep(0, n_xvars)
  } else if (type == "pfi") {
    for(i in indices_adj){
      x_adj[i,var_group] <-
        sample(x = x[i,var_group], size = n_xvars, replace = F)
    }
  } else {
    stop("'type' specified incorrectly. Must be 'zfi' or 'pfi'.")
  }
    
  # Prepare data for ESN with adjusted times
  data_obj_adj <-
    create_data_obj_ood(
      model = model, 
      x_ood = x_adj, 
      t_ood = model$data_input$t
    )
  
  # Compute h matrix with adjusted values
  h_obj_adj <-
    create_h(
      U_and_W = model$param_est,
      data_obj = data_obj_adj,
      add_quad = model$add_quad,
      nh = model$params_tuning$nh,
      h_start = rep(0, model$params_tuning$nh)
    )
  
  # Fill in model with adjusted values
  model_adj = model
  model_adj$data_train$x_train = data_obj_adj$x_ood
  model_adj$data_train$x_train_scaled = data_obj_adj$x_ood_scaled
  model_adj$data_train$x_oos = data_obj_adj$x_ood_oos
  model_adj$data_train$emb_vecs = data_obj_adj$emb_vecs
  model_adj$data_train$design_matrix = data_obj_adj$design_matrix
  model_adj$h = h_obj_adj
  
  # Specify t_forecast and associated index
  y_index_pred = index_adj + model$params_tuning$tau
  
  # Determine index in h based on forecast time
  y_train_times_index = 
    y_index_pred - 
    model$params_tuning$tau - 
    (model$params_tuning$m * model$params_tuning$tau_emb)
  
  # Compute predictions
  preds_adj = t(model_adj$param_est$V %*% model_adj$h$h[,y_train_times_index])
  
  # Remove scaling (if previously applied)
  if (model$internal_scaling == "joint") {
    y_train_mean = model_adj$data_train$y_train_mean
    y_train_sd = model_adj$data_train$y_train_sd 
    preds_adj = (preds_adj * y_train_sd) + y_train_mean
  }
  
  # Add times to predictions
  rownames(preds_adj) = model_adj$data_train$y_train_times[y_train_times_index]
  
  # Convert back to spatial scale is requested
  if (!is.null(phi)) {
    preds_adj = preds_adj %*% t(phi)
  }
  
  # Scale predictions if requested
  if (scale_y) preds_adj = scale(preds_adj)
  
  # Compute RMSEs with adjusted data
  if (is.null(weights)) {
    rmses_adj = sqrt(rowMeans((y_obs[y_train_times_index,] - preds_adj)^2))  
  } else {
    rmses_adj = 
      sqrt(
        rowSums(weights * (y_obs[y_train_times_index,] - preds_adj)^2) / 
          sum(weights)
      )
  }

  # Put RMSEs in data frame
  res <- 
    data.frame(
      t_adj = model$data_train$x_train_times[index_adj], 
      vars_adj = paste(var_group, collapse = ","),
      rep = rep, 
      rmses_adj = rmses_adj
    )
  if (is.null(rep)) res <- res %>% dplyr::select(-rep)
  if (return_adj_preds) {
    res = cbind(res, preds_adj)
  }
  
  # Return adjusted RMSEs
  return(res)
  
}
